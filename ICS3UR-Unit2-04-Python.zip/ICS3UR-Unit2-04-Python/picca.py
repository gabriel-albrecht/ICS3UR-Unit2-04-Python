#!/usr/bin/env python3
# Created by Gabriel A
# Created on Nov 2020
# This module contains constants for the pizza program

labour = 0.75
rent = 1.00
cpi = 0.50
tax = 0.13
