#!/usr/bin/env python3

# Created by Gabriel A
# Created on Nov 2020
# This program calculates the cost of pizza

import picca


def main():
    # calculates the cost of pizza

    # input
    diameter = int(input("Enter the diameter of the pizza you would " + "like (inch): "))

    # process
    sub_total = picca.labour + picca.rent + (diameter * picca.cpi)
    total = sub_total + (sub_total * picca.tax)

    # output
    print("")
    print("The cost for a {0} inch pizza is: ${1:,.2f}".format(diameter, total))


if __name__ == "__main__":
    main()
